"""Snap Harvester v2.0 — ML-enhanced ShockFlip swing engine."""
